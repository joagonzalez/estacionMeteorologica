// **************************************************************************
// * Alumnos: Diego Aranda - David Benoit
// * Electronica Digital II
// * Proyecto Final- Cargador de Bateria
// *
// * Documentacion:
// *   	- UM10503 (LPC43xx ARM Cortex-M4/M0 multi-core microcontroller User Manual)
// *   	- PINES UTILIZADOS DEL NXP LPC4337 JBD144 (Ing. Eric Pernia)
// **************************************************************************

#include<stdio.h> 

#include "uart.h"
#include "BAT.h"

#define ADC_CHANNEL 3
unsigned short  ADC_BUF = 0;
int i = 0;

volatile int ticks = 0;		// cuenta las veces que el Systtick llego a cero
volatile int ledStatus = 0; // estado del led indicador de toma de muestra
volatile int delay_ms = 50;	// Control de la velocidad de la toma de muestras
int Carga = 0;
char Dato_Carga='0';
int ADC=0;
unsigned int tmp;

void SysTick_Handler(void){

	ticks++;
}
// blocks for dlyTicks  (en microsegundos)
static void Delay(int dlyTicks) 
{
    int curTicks;
 
    curTicks = ticks;
    while ((ticks - curTicks) < dlyTicks);
}

void SysTickConfig(void){
	
	_SysTick->CTRL = 0x00;
	_SysTick->LOAD = 0x00000CC; // Es la cuenta que lleva el registro para llegar a el valor un microsegundo con los 208MHZ del clock.
	_SysTick->VAL = 0x00; 
	_SysTick->CTRL = 0x05;
    _SysTick->CTRL = 0x07;
				 
}

static void ADC_Config(void) {

	ADC0->CR |=	(1 << ADC_CHANNEL) |		// Seleccion canal ADC0
				(231 << 8) |	// ADC0 clkdiv (maximo = 255) => Freq = 204MHz / (11 * (clkdiv + 1))
				(0 << 16) |		// Burst mode => Repeated conversions
				(0 << 17) |		// 10 bits resolution
				(1 << 21) |		// Power on
				(0 << 24) |		// Conversion start => Burst controlled (not software)
				(0 << 27) ;		// Start signal edge => Burst => Not significant bit
				
}


void LED_ON(enum LEDS led) {
	
	switch(led) {
		case 0:
			GPIO_PORT->SET[0] |= (1 << 14);
			break;
		case 1:
			GPIO_PORT->SET[1] |= (1 << 11);
			break;
		case 2:
			GPIO_PORT->SET[1] |= 1 << 12;
			break;
		case 3:
			GPIO_PORT->SET[5] |= 1 << 0;
			break;
		case 4:
			GPIO_PORT->SET[5] |= 1 << 1;
			break;
		case 5:
			GPIO_PORT->SET[5] |= 1 << 2;
			break;
	}
}

void LED_OFF(enum LEDS led) {
	
	switch(led) {
		case 0:
			GPIO_PORT->CLR[0] |= (1 << 14);
			break;
		case 1:
			GPIO_PORT->CLR[1] |= (1 << 11);
			break;
		case 2:
			GPIO_PORT->CLR[1] |= 1 << 12;
			break;
		case 3:
			GPIO_PORT->CLR[5] |= 1 << 0;
			break;
		case 4:
			GPIO_PORT->CLR[5] |= 1 << 1;
			break;
		case 5:
			GPIO_PORT->CLR[5] |= 1 << 2;
			break;
	}
}
void Cfg_Led(void){


	// Configuracion de pines
	
	SCU->SFSP[2][10] = (SCU_MODE_EPUN | SCU_MODE_FUNC0); // P2_10, GPIO0[14], LED1
	SCU->SFSP[2][0] = (SCU_MODE_DES | SCU_MODE_FUNC4); // P2_0, GPIO5[0], LED0_R
	SCU->SFSP[2][1] = (SCU_MODE_DES | SCU_MODE_FUNC4); // P2_1, GPIO5[1], LED0_G
	SCU->SFSP[2][2] = (SCU_MODE_DES | SCU_MODE_FUNC4); // P2_2, GPIO5[2], LED0_B
	SCU->SFSP[2][11] = (SCU_MODE_DES | SCU_MODE_FUNC0);// P2_11, GPIO1[11], LED2
	SCU->SFSP[2][12] = (SCU_MODE_DES | SCU_MODE_FUNC0);// P2_12, GPIO1[12], LED3

	
	GPIO_PORT->DIR[0] |= 1 << 14;    // led 1 Rojo
	GPIO_PORT->DIR[1] |= 1 << 11;    // Led 2 Amarillo
	GPIO_PORT->DIR[1] |= 1 << 12;    // Led 3 Verde
	GPIO_PORT->DIR[5] |= 1 << 0;     // LED0_R
	GPIO_PORT->DIR[5] |= 1 << 1;     // LED0_G
	GPIO_PORT->DIR[5] |= 1 << 2;     // LED0_B
	
	
}	

void Config_CARGA(void) {
	//Configuracion del pin (CARGA) como GPIO
	// (Registro de configuracion, pag 405 / Tabla 191)
	SCU->SFSP[6][1] = (SCU_MODE_DES | SCU_MODE_FUNC0); // P6_1, GPIO3[0], CARGA  SCU_MODE_DES Resistencias deshabilitadas

	//Configuracion del pin (CARGA) como salida
	// (Registro de direccion, pag 455 -> Tabla 261)
	GPIO_PORT->DIR[3] |= 1 << 0;     // P6_1, GPIO3[0], CARGA 
		
}

void Config_UART2(void)
{

	UART_Iniciar(LPC_USART2);		      // Inicio de la UART
	UART_CofigBaudios(LPC_USART2, 9600);  // Configurar Baud rate 9600
	
	//Reconfigurar UART2 8 bit de datos 1 bit stop, habilitar fifo y habilitar la transimision TX
	
	LPC_USART2->LCR = (UART_LCR_WLEN8 | UART_LCR_SBS_1BIT);
	LPC_USART2->FCR = (UART_FCR_FIFO_EN | UART_FCR_TRG_LEV0);
	LPC_USART2->TER2 = UART_TER2_TXEN;

    //Configuracion de pines UART2 FUNC6
	/* P7_1: UART2_TXD */
	SCU->SFSP[7][1] = (MD_PDN | SCU_MODE_FUNC6);
	/* P7_2: UART2_RXD */
	SCU->SFSP[7][2] = (MD_PLN | SCU_MODE_EZI | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC6);	
}

void metodo_carga1(void)
{
	
	//periodo=5ms con 6000 ciclos de while son 30 segundos
	int aux=0;
	while(aux<(6000-1)){
		GPIO_PORT->SET[3] |= (1 << 0); //P6_1 GPIO03[0]     *** CARGA_ON  ***
		Delay(1*1000);	               //Tiempo activo 1ms
		GPIO_PORT->CLR[3] |= (1 << 0); //P6_1 GPIO03[0]     *** CARGA_OFF ***
		Delay(4*1000);	               //Tiempo off 4ms
		aux++;}
	
}

void metodo_carga2(void)
{
	
	//periodo=500ms con 60 ciclos de while son 30 segundos
	int aux=0;
	while(aux<(60-1)){
		GPIO_PORT->SET[3] |= (1 << 0); //P6_1 GPIO03[0]  	*** CARGA_ON  ***
		Delay(450*1000);	           //Tiempo activo 450ms
		GPIO_PORT->CLR[3] |= (1 << 0); //P6_1 GPIO03[0]     *** CARGA_OFF ***
		Delay(50*1000);	               //Tiempo off 50ms
		aux++;}
	
}

void metodo_carga3(void)
{
	
	//periodo=2ms con 15000 ciclos de while son 30 segundos
	int aux=0;
	while(aux<(15000-1)){
	//DEBUGSTR("\r\n Incializando... metodo_carga3..entro al while \n");
	GPIO_PORT->SET[3] |= (1 << 0); //P6_1 GPIO03[0]  	*** CARGA_ON  ***
	Delay(100);	                   //Tiempo activo 0.1ms es decir 100us
	GPIO_PORT->CLR[3] |= (1 << 0); //P6_1 GPIO03[0]     *** CARGA_OFF ***
	Delay(1900);	               //Tiempo off 1.9ms es decir 1900us
	aux++;}
}

// Funcion que obtiene el valor del ADC 
int ResultadoADC(void){
	
				ADC0->CR = (1 << 24) | (ADC0->CR);
				while ((ADC0->STAT && 0b1000) == 0){}
				ADC_BUF = (ADC0->DR[ADC_CHANNEL] >> 6) & 0x3FF;
				return ADC_BUF;
}


// Funciones para convertir variable entera a char 

void strreverse(char* begin, char* end)
{  
    char aux;  
    while(end>begin)   
        aux=*end, *end--=*begin, *begin++=aux; 
}

void itoa_(int value, char *str)
{
    char* wstr=str;
    int sign;  
    //div_t res;
   
    if ((sign=value) < 0) value = -value;
   
    do {   
      *wstr++ = (value%10)+'0';
	 
	}while(value=(value/10)); //da un warning el compilador.. 
   
    if(sign<0) *wstr++='-';
    *wstr='\0';

    strreverse(str,wstr-1);
}

void Imprimir_UART2(void)
{
int conv;	
int tam1=30;
int tam2=16;
int tam3=32;
int tam4=21;
int tam5=3;

//Cadenas de caracteres a enviarse por la UART
char c;
char cadena1[30]="SISTEMA DE CARGADOR DE BATERIA";
char cadena2[16]="METODO DE CARGA:";
char cadena3[32]="Bateria Descargada...Cargando...";
char cadena4[21]="***BATERIA CARGADA***";
char cadena5[4]="0604";//variable temporal ..se copia el valor del ADC y se convierte

//IMPRESION EN UART SISTEMA DE CARGADOR DE BATERIA
//Envia caracteres de siguiente linea y carry return 
  enviarChar('\n');
  enviarChar('\r');
  enviarChar('\n');
//Transforma la cadena y envia un caracter por vez
  for (int i=0; i<tam1; i++)
{
  c=cadena1[i];
  enviarChar(c);
  }
enviarChar(' ');  
//FIN IMPRESION EN UART


//IMPRESION EN UART METODO DE CARGA
//Envia caracteres de siguiente linea y carry return 
  enviarChar('\n');
  enviarChar('\r');
  enviarChar('\n');
//Transforma la cadena y envia un caracter por vez
  for (int i=0; i<tam2; i++)
{
  c=cadena2[i];
  enviarChar(c);
  }
//Envia el metodo de carga 
enviarChar(' ');  
enviarChar(Dato_Carga);
//FIN IMPRESION EN UART

//IMPRESION EN UART ESTADO DE CARGA
//Envia caracteres de siguiente linea y carry return 
  enviarChar('\n');
  enviarChar('\r');
  enviarChar('\n');

     if (ADC>=1000)             //  Bateria Cargada
	{
  //Transforma la cadena y envia un caracter por vez
  for (int i=0; i<tam4; i++)
  {
  c=cadena4[i];
  enviarChar(c);
  }
	}else                       // Bateria Descargada
	{
      //Transforma la cadena y envia un caracter por vez
      for (int i=0; i<tam3; i++)
      {
       c=cadena3[i];
       enviarChar(c);
      }
	
	};
//FIN IMPRESION EN UART

//IMPRESION EN UART VARIABLE ADC CONVERTIDO A mV
//Envia caracteres de siguiente linea y carry return 
  enviarChar('\n');
  enviarChar('\r');
  enviarChar('\n');
  tam5=4;
  conv=(4140*ADC)/1000; //Convierte el valor del ADC (0 1023) en miliVolts segun circuito
  itoa_(conv,cadena5);  //Toma/convierte los datos del entero conv(ADC) a la cadena5 en char 
//Transforma la cadena y envia un caracter por vez
  for (int i=0; i<tam5; i++)
{
  c=cadena5[i];
  enviarChar(c);
  }
  
enviarChar(' ');
enviarChar('m');
enviarChar('V');
//FIN IMPRESION EN UART


}

int medir_tension(void)
{
	LED_OFF(0);
	LED_OFF(1);
	LED_OFF(2);
	LED_OFF(3);
	LED_OFF(4);
	LED_OFF(5);
	Carga=0;
	ADC=ResultadoADC(); //Actualiza la variable ADC 
	//ADC=600;          //Prueba de Carga=1
	//ADC=780;          //Prueba de Carga=2
	//ADC=1000;         //Prueba de Carga=3

	 if (ADC<=609){              //  (tension bat<=2.5)
		Carga=1;
	    Dato_Carga='1';
	    Imprimir_UART2();
	}else {
		//Imprimir_UART2();	
	};
		
	 if ((ADC>609)&&(ADC<1000)){ //  ((tension bat<=2.5)&&(tension bat<4.2))
		Carga=2;
	    Dato_Carga='2'; 
	    Imprimir_UART2();
		}else {
		//Imprimir_UART2();	
	};
     if (ADC>=1000)             //  (tension bat>=4.2)
	{
		Carga=3;
		Dato_Carga='3'; 
		Imprimir_UART2();
	}else {
		//Imprimir_UART2();	
	};
	
	return Carga;
}


int main(void) {

	Config_CARGA();     // P6_1, GPIO3[0], CARGA como salida SCU_MODE_DES Resistencias de PullDown Desactivadas 
	Config_UART2();     // Configuracion de la UART2
	Cfg_Led();  		// Configura los Leds
	LED_OFF(0);         // Apagar LED 
	LED_OFF(1);         // Apagar LED 
	LED_OFF(2);         // Apagar LED 
	LED_OFF(3);         // Apagar LED 
	LED_OFF(4);         // Apagar LED 
	LED_OFF(5);         // Apagar LED  
	SysTickConfig();    // Establecimiento de la cuenta del SysTick
	ADC_Config();		// Configuracion del ADC
	Carga=1;            // Inicializa Carga con un valor
	LED_ON(2);		    // Indicacion de Encendido LED Verde
	Delay(1000*1000);	//1 Seg Led Verde Encendido
	
// Cargador Bateria
		while(Carga!=4){
		Carga=medir_tension(); // Llama a la funcion medir_tension y obtiene el valor de tension
				
			switch(Carga) {
			case 1 :
			{
				
				LED_ON(0);      //Enciende LED
				metodo_carga1();// Llama a funcion de Carga1
				LED_OFF(0);     // Apaga LED
			}
				break;
			case 2 :
			{
				
				LED_ON(1);      //Enciende LED
				metodo_carga2();// Llama a funcion de Carga2
				LED_OFF(1);     // Apaga LED
			}
			break;
			case 3 :
			{
				
				LED_ON(2);      //Enciende LED
				metodo_carga3();// Llama a funcion de Carga3
				LED_OFF(2);     // Apaga LED
			}
			break;

		}
	}
	
	
	// Programa Terminado
	return 0;
}
